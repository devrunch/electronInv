-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Patient" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "patientId" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "medicalHistory" TEXT NOT NULL DEFAULT '',
    "dob" DATETIME NOT NULL,
    "gender" TEXT NOT NULL,
    "contactInfo" TEXT NOT NULL,
    "emergencyContact" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_Patient" ("contactInfo", "createdAt", "dob", "emergencyContact", "firstName", "gender", "id", "lastName", "medicalHistory", "patientId") SELECT "contactInfo", "createdAt", "dob", "emergencyContact", "firstName", "gender", "id", "lastName", "medicalHistory", "patientId" FROM "Patient";
DROP TABLE "Patient";
ALTER TABLE "new_Patient" RENAME TO "Patient";
CREATE UNIQUE INDEX "Patient_patientId_key" ON "Patient"("patientId");
CREATE UNIQUE INDEX "Patient_contactInfo_key" ON "Patient"("contactInfo");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
