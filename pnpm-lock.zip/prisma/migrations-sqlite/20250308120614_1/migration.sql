-- CreateTable
CREATE TABLE "Purchase" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "supplierMail" TEXT NOT NULL,
    "inventoryId" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "price" REAL NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Purchase_supplierMail_fkey" FOREIGN KEY ("supplierMail") REFERENCES "Supplier" ("email") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Purchase_inventoryId_fkey" FOREIGN KEY ("inventoryId") REFERENCES "Inventory" ("sku") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Inventory" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "sku" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 0,
    "lowerThreshold" INTEGER NOT NULL DEFAULT 5,
    "upperThreshold" INTEGER NOT NULL DEFAULT 100,
    "lastUpdated" DATETIME NOT NULL,
    "supplierId" INTEGER,
    "price" REAL NOT NULL DEFAULT 0,
    CONSTRAINT "Inventory_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Inventory" ("id", "lastUpdated", "lowerThreshold", "name", "quantity", "sku", "supplierId", "upperThreshold") SELECT "id", "lastUpdated", "lowerThreshold", "name", "quantity", "sku", "supplierId", "upperThreshold" FROM "Inventory";
DROP TABLE "Inventory";
ALTER TABLE "new_Inventory" RENAME TO "Inventory";
CREATE UNIQUE INDEX "Inventory_sku_key" ON "Inventory"("sku");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
