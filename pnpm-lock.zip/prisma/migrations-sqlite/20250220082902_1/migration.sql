/*
  Warnings:

  - You are about to drop the column `medicalHistory` on the `Patient` table. All the data in the column will be lost.
  - You are about to drop the column `patientId` on the `Patient` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Dosage" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "prescriptionId" INTEGER NOT NULL,
    "sku" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 0,
    "frequency" TEXT NOT NULL,
    CONSTRAINT "Dosage_prescriptionId_fkey" FOREIGN KEY ("prescriptionId") REFERENCES "Prescription" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dosage_sku_fkey" FOREIGN KEY ("sku") REFERENCES "Inventory" ("sku") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Dosage" ("frequency", "id", "prescriptionId", "sku") SELECT "frequency", "id", "prescriptionId", "sku" FROM "Dosage";
DROP TABLE "Dosage";
ALTER TABLE "new_Dosage" RENAME TO "Dosage";
CREATE TABLE "new_MedicalHistory" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "patientId" INTEGER NOT NULL,
    "description" TEXT NOT NULL,
    "diagnosis" TEXT NOT NULL,
    "treatment" TEXT NOT NULL,
    "doctor" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "MedicalHistory_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES "Patient" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_MedicalHistory" ("createdAt", "description", "diagnosis", "doctor", "id", "patientId", "treatment") SELECT "createdAt", "description", "diagnosis", "doctor", "id", "patientId", "treatment" FROM "MedicalHistory";
DROP TABLE "MedicalHistory";
ALTER TABLE "new_MedicalHistory" RENAME TO "MedicalHistory";
CREATE TABLE "new_Patient" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "dob" DATETIME NOT NULL,
    "gender" TEXT NOT NULL,
    "contactInfo" TEXT NOT NULL,
    "emergencyContact" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_Patient" ("contactInfo", "createdAt", "dob", "emergencyContact", "firstName", "gender", "id", "lastName") SELECT "contactInfo", "createdAt", "dob", "emergencyContact", "firstName", "gender", "id", "lastName" FROM "Patient";
DROP TABLE "Patient";
ALTER TABLE "new_Patient" RENAME TO "Patient";
CREATE UNIQUE INDEX "Patient_contactInfo_key" ON "Patient"("contactInfo");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
