-- DropForeignKey
ALTER TABLE "InventoryLog" DROP CONSTRAINT "InventoryLog_inventoryId_fkey";

-- AlterTable
ALTER TABLE "InventoryLog" ALTER COLUMN "inventoryId" SET DATA TYPE TEXT;

-- AddForeignKey
ALTER TABLE "InventoryLog" ADD CONSTRAINT "InventoryLog_inventoryId_fkey" FOREIGN KEY ("inventoryId") REFERENCES "Inventory"("sku") ON DELETE CASCADE ON UPDATE CASCADE;
