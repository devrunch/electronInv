-- AlterTable
ALTER TABLE "Prescription" ADD COLUMN     "disease" TEXT NOT NULL DEFAULT '';
