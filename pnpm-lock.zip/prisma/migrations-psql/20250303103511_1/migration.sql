-- AlterEnum
ALTER TYPE "LogType" ADD VALUE 'DELETE';
