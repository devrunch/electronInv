const puppeteer = require('puppeteer');

/**
 * Converts HTML content to PDF buffer
 * @param {string} htmlContent - The HTML content to convert
 * @param {Object} options - PDF generation options
 * @param {string} options.format - Paper format (A4, Letter etc.)
 * @param {boolean} options.landscape - Landscape or portrait
 * @param {Object} options.margin - Page margins
 * @returns {Promise<Buffer>} PDF buffer
 */
async function htmlToPdfBuffer(htmlContent, options = {}) {
    const browser = await puppeteer.launch({
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    try {
        const page = await browser.newPage();

        // Set content and wait for network idle to ensure images are loaded
        await page.setContent(htmlContent, {
            waitUntil: ['networkidle0', 'load', 'domcontentloaded']
        });

        // Default options
        const defaultOptions = {
            format: 'A4',
            landscape: false,
            margin: { top: '1cm', right: '1cm', bottom: '1cm', left: '1cm' },
            printBackground: true, // To include background colors and images
            preferCSSPageSize: true,
            ...options
        };

        // Generate PDF
        const pdfBuffer = await page.pdf(defaultOptions);

        return pdfBuffer;
    } finally {
        await browser.close();
    }
}

/**
 * Example usage:
 * const html = `
 *   <html>
 *     <head>
 *       <style>
 *         body { font-family: Arial; }
 *         .header { color: blue; }
 *       </style>
 *     </head>
 *     <body>
 *       <h1 class="header">Hello World</h1>
 *       <img src="https://example.com/image.jpg" />
 *     </body>
 *   </html>
 * `;
 * 
 * const pdfBuffer = await htmlToPdfBuffer(html, {
 *   format: 'A4',
 *   landscape: false,
 *   margin: { top: '2cm', right: '2cm', bottom: '2cm', left: '2cm' }
 * });
 */

module.exports = htmlToPdfBuffer; 